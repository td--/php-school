<?php
$i=1;
while ($i==$i){
echo 'Endlosschleife<br>';
}
?>